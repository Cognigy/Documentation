# Introduction 
This repo contains all the scripts for the kustomization to helm migration

## Secret migration
To migrate all secrets to `cognigy-ai` namespace and at the same time we have to make it compatible with helm. We have written a python script named `secret-migration.py` to do it. 

### Build and Test

1. Install the necessary package

    ```
    cd secret-migration
    pip install -r requirements.txt
    ```
2. Make sure that `secret-migration.py` with the same level of the existing `secrets` folder in the directory tree.
3. Run the script

    ```
    python secret-migration.py -ns cognigy-ai
    ```

Here `-ns` parameter is representing the target namespace fopr cognigy-ai deployment. The default value of this parameter is `cognigy-ai`. 
This will generate the modified secrets and store it under `migration-secrets` folder. You can then deploy the secrets in `cognigy-ai` or your choice of namerspace. 
